package system;

public interface Funcionario {
     double calcularBonus();
}

//Classe FuncionarioAssalariado implementada a Funcionario
 class FuncionarioAssalariado implements Funcionario{
	private double TotalAnual;
	
	public FuncionarioAssalariado(double TotalAnual) {
		this.TotalAnual = TotalAnual;
	}

	public double calcularBonus() {
		return TotalAnual + 5000;
	}
	
}

 //Classe FuncionarioHorista implementada a Funcionario
	 class FuncionarioHorista implements Funcionario{
		
		private double TotalAnual;
		
		public FuncionarioHorista(double TotalAnual) {
			this.TotalAnual = TotalAnual;
		}
		
		public double calcularBonus() {
			return TotalAnual *0.10;
		}
	}
	
	
	class Main{
		public static void main(String[]args) {
			
			Funcionario funcionarioAssalariado = new FuncionarioAssalariado(0);
			  System.out.println("Bônus no final do ano R$" + funcionarioAssalariado.calcularBonus());
		
		
		Funcionario funcionarioHorista = new FuncionarioAssalariado(0);
		      System.out.println("Bônus no final do ano R$" + funcionarioHorista.calcularBonus());
	    }
	}
